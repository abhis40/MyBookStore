// import React from 'react'


import { useEffect, useState } from "react";

import Cards from "./Cards";
import {Link} from "react-router-dom";
import axios from "axios";

function AllBooks() {
   const [book,setBook] = useState([])
   useEffect(()=>{
        const getBook = async()=>{
            try{
               const res = await axios.get("http://localhost:4001/book");
               console.log(res.data);
               setBook(res.data)
            }catch(error){
                console.log(error)
            }
        }
        getBook();
   },[])
  return (
    <>
    <div className="max-w-screen-2xl container max-auto md:px-20 px-4">
        <div className="mt-28 items-center justify-center text-center">
            <h1 className="text-2xl  md:text-4xl">Welcome you All Here</h1>
           
            <p className="mt-10">Welcome to our All Books page, where the world of literature awaits! Dive into a diverse collection featuring gripping mysteries, heartwarming romances, epic adventures, and thought-provoking non-fiction. Explore new worlds, meet unforgettable characters, and let our books ignite your imagination with their timeless stories. Whether you seek escapism, knowledge, or relaxation, there's something here for every reader. Start your literary journey today and get lost in the magic of words!</p>
        
        <Link to="/">
        <button className="bg-blue-500 text-white px-4 py-3 rounded-md mt-4 ">Back To Home</button>
        </Link>
       
        </div>

        <div className="mt-3 grid grid-cols-1 md:grid-cols-3">
            {
                book.map((item)=>(
                    <Cards key={item.id} item={item}></Cards>
                ))
            }
        </div>

    </div>
    </>
  )
}

export default AllBooks
