// import React from 'react'
import Navbar from '../components/Navbar'
import AllBooks from '../components/AllBooks'
import Footer from '../components/Footer'

function BooksDetails() {
  return (
    <>
    <Navbar></Navbar>
    <div className='min-h-screen'>
    <AllBooks></AllBooks>
    </div>
    
    <Footer></Footer>
    </>
  )
}

export default BooksDetails
