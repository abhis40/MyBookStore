
import BooksDetails from "./Books/BooksDetails";
import SignUp from "./components/SignUp";
import Home from "./home/Home";
import {Navigate, Route,Routes} from "react-router-dom";
import { Toaster } from 'react-hot-toast';
import { useAuth } from "./context/AuthProvider";

 function App() {
  const [authUser,setAuthUser]=useAuth()
  console.log(authUser);

  return (
    <>
      
    <Routes>
      <Route path="/" element={<Home></Home>}></Route>
      <Route path="/AllBooks" element={authUser?<BooksDetails></BooksDetails>:<Navigate to="/Signup"></Navigate>}></Route>
      <Route path="/SignUp" element={<SignUp></SignUp>}></Route>
    </Routes>
    <Toaster></Toaster>
   </>
  )
}
export default App;